package Repository;

import Classes.RandomNum;
import Entity.User;
import Exceptions.RegistrationException;
import Exceptions.UserAccessException;
import Helpers.ConfigHelper;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * The user repository.
 * @author Shivangi Prajapati
 */
public final class UserRepository {
    private Connection connection;
    private static final Logger logger = Logger.getLogger(UserRepository.class.getName());
    
    public UserRepository()
    {
        this.Connect();
    }
    
     /**
     * The method to connect to the database service.
     */
    public void Connect()
    {    
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            this.connection = DriverManager.getConnection(ConfigHelper.getDbUrl(), ConfigHelper.getUser(),ConfigHelper.getPassword());
            
        }catch(ClassNotFoundException | SQLException  ex)
        {
            logger.log(Level.SEVERE, "Exception in connection", ex.getMessage());
        }
    }    
    
    /**
     * The method to disconnect from the service.
     */
    public void Close()
    {
        try{
            if(this.connection != null){
            this.connection.close();}
        }catch(SQLException ex)
        {   ex.printStackTrace();
        }
    }
    
    /**
     * The method used to get user details when logging in performed.
     * @param username to find the correct user.
     * @param password to find the correct user.
     * @return true when a correct combination has been found.
     * @throws UserAccessException when errors are encountered.
     */
    public User getUser(String username , String password) throws UserAccessException
    {
        User user = new User();
        
        String r= "it didnt work";
        try{
           
           user = this.verifyUser(username);
           if(user!= null && user.getPassword().equals(password))
           {
              return user;
           }
        }
        catch(Exception ex)
        {
           throw new UserAccessException("Login error:"+ ex.getLocalizedMessage());
        }
        return null;
    }
    
    /**
    * The method to add a new user when register activity is performed.
    * @param newUser user details to be added in the database.
    * @return true when action completed successfully.
    * @throws RegistrationException when errors are encountered.
    */
    public User addUser(User newUser) throws RegistrationException
    {     
        try
        {            
            /// verify if the user exists already
            if(this.verifyUser(newUser.getUsername()) == null){
            
                // generate ID:
                newUser.setId(RandomNum.getNumber());
                
                String st= "INSERT INTO User (ID, Username, Password, FullName) VALUES(?,?,?,?)";
                try(PreparedStatement prepSt =this.connection.prepareStatement(st))
                {
                    prepSt.setString(1, newUser.getId());
                    prepSt.setString(2, newUser.getUsername());
                    prepSt.setString(3, newUser.getPassword());
                    prepSt.setString(4, newUser.getFullName());
                    prepSt.executeUpdate();
                } 
            }
            else 
            {
               return null;
            }              
        }catch(SQLException ex)
        {
            throw new RegistrationException("Registering error:"+ ex.getLocalizedMessage());
        } 
        return newUser;
    }
    
    /**
     * The method to verify if the user actually exists.
     * @param username for checking if the user exists.
     * @return user details when a match is found. 
     */
    public User verifyUser(String username)
    {
        User dbUser = new User();
        try
        {
           String getusers="Select * From User Where Username='"+username+"'";
           ResultSet results =this.connection.createStatement().executeQuery(getusers);
           if(results.next())
           {
               dbUser.setId(results.getString("ID"));
               dbUser.setUsername(results.getString("Username"));
               dbUser.setPassword(results.getString("Password"));
               dbUser.setFullName(results.getString("FullName"));
           }
           else 
           {
               dbUser = null;
           }
           
        }catch(SQLException ex)
        {
            //Log.error(ex.getMessage());
            logger.log(Level.SEVERE, "Exception in verify user:", ex);
        } 
        
        return dbUser;
    }
}

