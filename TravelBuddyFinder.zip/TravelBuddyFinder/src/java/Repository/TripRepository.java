package Repository;

import Entity.WeatherConditions;
import Entity.Tour;
import Exceptions.TripException;
import Helpers.ConfigHelper;
import Helpers.JsonHelper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The trip repository.
 * @author Shivangi Prajapati
 */
public class TripRepository {
    private Connection connection;
    private static final Logger logger = Logger.getLogger(UserRepository.class.getName());
    
    public TripRepository()
    {
        this.Connect();
    }
    
    /**
     * The method to connect to the database service.
     */
    public String Connect()
    {    
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            this.connection = DriverManager.getConnection(ConfigHelper.getDbUrl(), ConfigHelper.getUser(),ConfigHelper.getPassword());
            
        }catch(ClassNotFoundException | SQLException  ex)
        {
            logger.log(Level.SEVERE, "Exception in connection", ex.getMessage());
        }
        
       return "Success";
    }    
    
    /**
     * The method to disconnect from the service.
     */
    public void Close()
    {
        try{
            if(this.connection != null){
            this.connection.close();}
        }catch(SQLException ex)
        {   ex.printStackTrace();
        }
    }
    
    /**
     * The method to add a new trip to the database.
     * @param tour details provided by client
     * @return returns the tours as success response
     * @throws TripException when an error is encountered 
     */
    public Tour addTrip(Tour tour) throws TripException
    { 
        try{     
            // convert the weather array into a jsonarray before adding into the database
            JsonArray weatherForecast = new JsonArray();            
            for (WeatherConditions conditions : tour.getWeatherCoditions()) {
                JsonObject jsonConditions = new Gson().toJsonTree(conditions).getAsJsonObject();
                weatherForecast.add(jsonConditions);
            }
            String st= "INSERT INTO Trips(ID,UserId,Location,ImgUrl,Description,StartDate,EndDate,Availability,ConfirmedBuddies,Weather) VALUES(?,?,?,?,?,?,?,?,?,?)";
            try(PreparedStatement tripSt =this.connection.prepareStatement(st))
                {
                    tripSt.setString(1, tour.getId());
                    tripSt.setString(2, tour.getUserId());
                    tripSt.setString(3, tour.getLocation());
                    tripSt.setString(4, tour.getImgUrl());
                    tripSt.setString(5, tour.getDescription());
                    tripSt.setString(6, tour.getStartDate());
                    tripSt.setString(7, tour.getEndDate());
                    tripSt.setInt(8, tour.getAvailability());
                    tripSt.setInt(9, tour.getConfirmedBuddies());
                    tripSt.setString(10, weatherForecast.toString());
  
                    tripSt.executeUpdate();
                }          
        }catch(SQLException ex)
        {
            throw new TripException(ex.getLocalizedMessage());//MessageLoader.getMessage("ER008"));
        }
        return tour;
    }
    
    /**
     * The method to get all the planned trips for the provided location.
     * @param userId for finding trips added by other users.
     * @param location the query parameter.
     * @return a list of retrieved trips.
     * @throws TripException when errors are encountered.
     */
    public ArrayList<Tour> getTourbyLocation(String userId, String location) throws TripException
    {
        ArrayList<Tour> allTrips= new ArrayList<>();
        try{
            
            String getusers="Select * From Trips Where UserId !='"+userId+"' AND Location='"+location+"'";
            ResultSet results = this.connection.createStatement().executeQuery(getusers);
            while(results.next())
            {   
               Tour singleTour = new Tour();
               ArrayList<WeatherConditions> weatherForcast = JsonHelper.parseDbWeather(results.getString("Weather"));
           
               singleTour.setId(results.getString("ID"));
               singleTour.setUserId(results.getString("UserId"));
               singleTour.setLocation(results.getString("Location"));
               singleTour.setImgUrl(results.getString("ImgUrl"));
               singleTour.setDescription(results.getString("Description"));
               singleTour.setStartDate(results.getString("StartDate"));
               singleTour.setEndDate(results.getString("EndDate"));
               singleTour.setAvailability(results.getInt("Availability"));
               singleTour.setConfirmedBuddies(results.getInt("ConfirmedBuddies"));
               singleTour.setWeatherCoditions(weatherForcast);
               
               allTrips.add(singleTour);
            }
        }catch(SQLException ex)
        {
            throw new TripException("Trip error:"+ ex.getMessage());
        }
        return allTrips;
    }
    
    /**
     * The method to retrieve all the trips added by current user.
     * @param userId current user id.
     * @return all the retrieved trips from the database.
     * @throws TripException when error is encountered.
     */
    public ArrayList<Tour> getUserTrips(String userId) throws TripException
    {
        ArrayList<Tour> allTrips= new ArrayList<>();
        try{
           
            String getusers="Select * From Trips Where UserId ='"+userId+"'";
            ResultSet results = this.connection.createStatement().executeQuery(getusers);
            while(results.next())
            {   
               Tour singleTour = new Tour();
               ArrayList<WeatherConditions> weatherForcast = JsonHelper.parseDbWeather(results.getString("Weather"));
           
               singleTour.setId(results.getString("ID"));
               singleTour.setUserId(results.getString("UserId"));
               singleTour.setLocation(results.getString("Location"));
               singleTour.setImgUrl(results.getString("ImgUrl"));
               singleTour.setDescription(results.getString("Description"));
               singleTour.setStartDate(results.getString("StartDate"));
               singleTour.setEndDate(results.getString("EndDate"));
               singleTour.setAvailability(results.getInt("Availability"));
               singleTour.setConfirmedBuddies(results.getInt("ConfirmedBuddies"));
               singleTour.setWeatherCoditions(weatherForcast);
               
               allTrips.add(singleTour);
            }            
        }catch(SQLException ex)
        {
            throw new TripException("Trip error:"+ ex.getMessage());
        }
        return allTrips;
    }
    
    /**
     * The method to delete a trip as per client request.
     * @param tripId to delete requested trip.
     * @return true when update is performed successfully.
     * @throws TripException when errors are encountered.
     */
    public Boolean deleteTrip(String tripId) throws TripException
    {
        try
        {
            String st= "DELETE FROM Trips WHERE id= ? ";
            try(PreparedStatement prepSt = this.connection.prepareStatement(st)){
                prepSt.setString(1, tripId);
                prepSt.executeUpdate();
            } 
            
        }catch(SQLException ex)
        {   
            //test = ex.getMessage();
            throw new TripException("Delete error:"+ ex.getLocalizedMessage());
        } 
        return true;
    }
}
