package Repository;

import Exceptions.RandomNumException;
import Helpers.ConfigHelper;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The random number repository.
 * @author Shivangi Prajapati
 */
public class RandomNumRepository {
    private Connection connection;
    private static final Logger logger = Logger.getLogger(UserRepository.class.getName());
    
    public RandomNumRepository()
    {
        this.Connect();
    }
    
    /**
     * The method to connect to the database service.
     */
    public void Connect()
    {    
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            this.connection = DriverManager.getConnection(ConfigHelper.getDbUrl(), ConfigHelper.getUser(),ConfigHelper.getPassword());
            
        }catch(ClassNotFoundException | SQLException  ex)
        {
            logger.log(Level.SEVERE, "Exception in connection", ex.getMessage());
        }
    }    
    
    /**
     * The method to disconnect from the service.
     */
    public void Close()
    {
        try{
            if(this.connection != null){
            this.connection.close();}
        }catch(SQLException ex)
        {   ex.printStackTrace();
        }
    }
    
    /**
     * The method to store all the new generated random numbers
     * @param randomNums new numbers
     */
    public void saveNumbers(ArrayList<String> randomNums) throws RandomNumException{
       
        String st= "INSERT INTO RandomNumbers(Num) VALUES(?)";
        
        try{
            if(this.connection.isClosed() || this.connection == null)
            {
                    this.Connect();
            }
            try(PreparedStatement numSt = this.connection.prepareStatement(st))
            {
                for(String num : randomNums){
                    numSt.setString(1, num);
                    numSt.addBatch();
                }
                numSt.executeBatch();
            }
        }catch(SQLException ex){
            throw new RandomNumException(ex.getLocalizedMessage());
        }
        
    }
    
    /**
     * The method to get the random number from the database
     * @return a random number
     * @throws RandomNumException when error is encountered
     */
    public String getNum() throws RandomNumException{
        String num = null;
        try{
            if(this.connection.isClosed()){
                    this.Connect();
            }
            String st = "{CALL GetNum()}";
            try(PreparedStatement prepSt = this.connection.prepareCall(st))
            {
                prepSt.execute();
                String response = "";
                try (ResultSet rs = prepSt.getResultSet()) {
                    if (rs != null && rs.next()) {
                         response = rs.getString(1);
                         num = response;
                    }
                }
            } 
        }catch(SQLException ex)
        {
            throw new RandomNumException(ex.getLocalizedMessage());
        }
        this.Close();
        return num;
    }
}