package Repository;

import Entity.Notification;
import Exceptions.NotificationException;
import Helpers.ConfigHelper;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The notification repository.
 * @author Shivangi Prajapati.
 */
public class NotificationRepository {
    private Connection connection;
    private static final Logger logger = Logger.getLogger(UserRepository.class.getName());
    
    public NotificationRepository()
    {
        this.Connect();
        
    }
    
    /**
     * The method to connect to the database service.
     */
    public void Connect()
    {    
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            this.connection = DriverManager.getConnection(ConfigHelper.getDbUrl(), ConfigHelper.getUser(),ConfigHelper.getPassword());
            
        }catch(ClassNotFoundException | SQLException  ex)
        {
            logger.log(Level.SEVERE, "Exception in connection", ex.getMessage());
        }
    }    
    
    /**
     * The method to disconnect from the service.
     */
    public void Close()
    {
        try{
            if(this.connection != null){
            this.connection.close();}
        }catch(SQLException ex)
        {   ex.printStackTrace();
        }
    }
    
    /**
     * The method to get all new notifications for the logged user.
     * @param userId for the accurate reading of data.
     * @return a list of all notifications.
     * @throws NotificationException when errors are encountered.
     */
    public ArrayList<Notification> getUserNotifications(String userId) throws NotificationException{
        ArrayList<Notification> userNotifications = new ArrayList<>();
        try
        {
            // call the database method to retrive all the notifications 
            String getusers="SELECT n.*,t.StartDate, t.EndDate, t.Availability, t.Location "
                   + "FROM Notifications n , Trips t "
                   + "WHERE n.RecipientId = '"+userId+"' AND n.TripId = t.Id AND n.isDisplayed = false"; 
            ResultSet results = this.connection.createStatement().executeQuery(getusers);
           
            while(results.next())
            {   
               Notification singleNotification = new Notification();
               
               singleNotification.setId(results.getString("Id"));
               singleNotification.setSenderId(results.getString("SenderId"));
               singleNotification.setRecipientId(results.getString("RecipientId"));
               singleNotification.setAccepted(results.getBoolean("Accepted"));
               singleNotification.setResponse(results.getBoolean("Response"));
               singleNotification.setRequest(results.getBoolean("Request"));
               singleNotification.setMessage(results.getString("Message"));
               singleNotification.setTripId(results.getString("TripId"));
               singleNotification.setAvailability(results.getInt("Availability"));
               singleNotification.setStartDate(results.getString("StartDate"));
               singleNotification.setEndDate(results.getString("EndDate"));
               singleNotification.setLocation(results.getString("Location"));
               
               userNotifications.add(singleNotification);
            }
        }catch(SQLException ex){
            
            throw new NotificationException("Trip error:"+ ex.getLocalizedMessage());
        }
        return userNotifications;
    }
    
    /**
     * The method to add a new notification and if the request is accepted, update the confirmed buddy column in trips table.
     * @param notification updated details for the user.
     * @return true when the actions is completed correctly.
     * @throws NotificationException when errors are encountered.
     */
    public Boolean addNotifications(Notification notification) throws NotificationException
    {
        
        try
        {
            String st = "{CALL AddNotification(?, ?, ?, ?, ?, ?, ?, ?)}";
            try(PreparedStatement prepSt = this.connection.prepareCall(st)){
                
                prepSt.setString(1, notification.getId());
                prepSt.setString(2, notification.getSenderId());
                prepSt.setString(3, notification.getRecipientId());
                prepSt.setString(4, notification.getTripId());
                prepSt.setBoolean(5, notification.getAccepted());
                prepSt.setBoolean(6, notification.getRequest());
                prepSt.setBoolean(7, notification.getResponse());
                prepSt.setString(8, notification.getMessage());

                prepSt.execute();
                
            } 
        }catch(SQLException ex)
        {
            throw new NotificationException("Registering error:"+ ex.getLocalizedMessage());
        } 
        return true;
    }
    
    /**
     * The method to update the status when a notification has been displayed to the end user.
     * @param tripId to identify the correct notification.
     * @param userId to identify the correct end user.
     * @return true when completed successfully
     * @throws NotificationException when errors are encountered.
     */
    public Boolean updateNotificationStatus(String tripId, String userId) throws NotificationException
    {
        try
        {
           String st= "UPDATE Notifications SET isDisplayed = true WHERE RecipientId =? AND TripId =? ";
            try(PreparedStatement prepSt = this.connection.prepareStatement(st)){                
                prepSt.setString(1, userId);
                prepSt.setString(2, tripId);
                prepSt.executeUpdate();                
            }            
        }catch(SQLException ex)
        {   
            throw new NotificationException("Update error:"+ ex.getLocalizedMessage());
        } 
        return true;
    }
}
