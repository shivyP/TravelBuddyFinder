package Helpers;

import java.util.ResourceBundle;

/**
 * The configuration helper
 * @author Shivangi Prajapati
 */
public class ConfigHelper {
    
    private static String DBURL;
    private static String USER;
    private static String PASSWORD;
    private static final String BUNDLE_NAME = "Resources.appsetting";
    private static ResourceBundle RESOURCE_BUNDLE;
    
    static {
        getDbConfig();
    }
    
    /**
     * The method to get the database configurations.
     */
    public static void getDbConfig()
    {
       try {
            RESOURCE_BUNDLE = ResourceBundle.getBundle(BUNDLE_NAME);
            DBURL = RESOURCE_BUNDLE.getString("Url");
            USER = RESOURCE_BUNDLE.getString("User");
            PASSWORD = RESOURCE_BUNDLE.getString("Password");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static String getDbUrl(){return DBURL;}
    public static String getUser(){return USER;}
    public static String getPassword(){return PASSWORD;}
    
}