package Helpers;

import Entity.User;
import java.util.HashMap;
import java.util.Map;

/**
 * The session data.
 * @author Shivangi Prajapati
 */
public class SessionData {
    
    public static final Map<String, User> CONSTANT_MAP = new HashMap<>();
    public static String CurrentUserKey;
}
