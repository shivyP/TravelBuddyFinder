package Helpers;

import Entity.WeatherConditions;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * The json helper
 * @author Shivangi Prajapati
 */
public class JsonHelper {
    
    private static final String JSONRPC = "jsonrpc";
    private static final String METHOD  = "generateUUIDs";
    private static final String NUM_IDS = "50";
    private static final String API_KEY = "8aaf106b-7e6f-416c-accf-a7eca258bacc";
    private static final String ID = "1"; // change the number here 
    
    /**
     * The method to format the data for the weather forecast search.
     * @param date in the required format.
     * @return 
     */
    public static String Date(Date date)
    {
         DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
         return df.format(date);
    }
    
    /**
     * The method to create the json request for the random org API request.
     * @return 
     */
    public static String createJsonRequest()
    {
        // create Json object
        JsonObject parameters = new JsonObject();
        parameters.addProperty("apiKey", API_KEY);
        parameters.addProperty("n", NUM_IDS);
        
        JsonObject requestObject = new JsonObject();
        
        // create properties 
        requestObject.addProperty("jsonrpc", JSONRPC);
        requestObject.addProperty("method", METHOD);
        requestObject.add("params", parameters);
        requestObject.addProperty("id", ID);
        return requestObject.toString();
    }
    
    /**
     * The method to parse the json response from the random org API.
     * @param jsonLine the response received from the API in json format.
     * @return the days section of the response.
     */
    public static ArrayList<String> parse(String jsonLine) {
        JsonElement pasreString = JsonParser.parseString(jsonLine);
        JsonObject  jobject = pasreString.getAsJsonObject();           
        jobject = jobject.getAsJsonObject("result");
        jobject = jobject.getAsJsonObject("random");
        JsonArray jarray = jobject.getAsJsonArray("data");
                
        ArrayList<String> randomNums = new ArrayList<>();
        
        System.out.println("Data: " + jarray);
        for(JsonElement jsonElement : jarray){
            randomNums.add(jsonElement.getAsString());
        }
        
      return randomNums;
    }

    /**
     * The method to parse the weather forecast response.
     * @param jsonLine the response from the API.
     * @return 
     */
    public static ArrayList<WeatherConditions> parseWeather(String jsonLine) 
    {
        // extract the days json array from the reponse retrvied from the API
        JsonElement pasreString = JsonParser.parseString(jsonLine);
        JsonObject  jobject = pasreString.getAsJsonObject();           
        JsonArray jarray = jobject.getAsJsonArray("days");   
        String weatherString = jarray.toString();
        return parseDbWeather(weatherString);
    }
  
    /**
     * The method to parse the weather information stored in the database.
     * @param weatherObject the information from the database.
     * @return 
     */
    public static ArrayList<WeatherConditions> parseDbWeather(String weatherObject)
    {
        //WeatherObject has trhe weather forcast for all days
        ArrayList<WeatherConditions> weatherForcast = new ArrayList<>();
        Gson gson = new Gson();
        JsonArray jsonArray = gson.fromJson(weatherObject, JsonArray.class);
        
        // get each of it and form an array to return 
        for(JsonElement obj: jsonArray)
        {
            JsonObject json = obj.getAsJsonObject();
            WeatherConditions currentCondition = gson.fromJson(json, WeatherConditions.class);
            weatherForcast.add(currentCondition);
        }
        return weatherForcast;
    }
   
    /**
     * The method to get the json object received in the get request.
     * @param jsonString the string in the request.
     * @return
     * @throws UnsupportedEncodingException 
     */
    public static String getJsonObject(String jsonString) throws UnsupportedEncodingException{
       
        String decodedJsonData = java.net.URLDecoder.decode(jsonString, "UTF-8");

        JsonObject jObj = JsonParser.parseString(decodedJsonData)
            .getAsJsonObject();
        return jObj.toString();
    }
    
    /**
     * The method to extract the image URL from the API response.
     * @param jsonString
     * @return 
     */
    public static String getImageLink(String jsonString){
                
        //JsonElement pasreString = new JsonParser().parse(jsonString);
        JsonArray  jarray = JsonParser.parseString(jsonString).getAsJsonArray();   
        JsonObject jObject = jarray.get(0).getAsJsonObject();
        JsonObject photoOject = jObject.getAsJsonObject("urls");
        String imageUrl = photoOject.get("regular").getAsString();
        if (imageUrl.length() > 0) {
            return imageUrl;
        } else {
            return "No link found";
        } 
    }
}
