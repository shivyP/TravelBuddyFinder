package Entity;

import java.util.ArrayList;

/**
 * The tour entity.
 * @author Shivangi Prajapati
 */
public class Tour {
    private String Id;
    private String Location;
    private String ImgUrl;
    private String Description;
    private String StartDate;
    private String EndDate;
    private String UserId;
    private int Availability;
    private int ConfirmedBuddies;
    private ArrayList<WeatherConditions> WeatherCoditions;
    
    public String getId() { return Id; }
    public void setId(String value) { this.Id = value; }
    
    public String getLocation() { return Location; }
    public void setLocation(String value) { this.Location = value; }
    
    public String getImgUrl() { return ImgUrl; }
    public void setImgUrl(String value) { this.ImgUrl = value; }
    
    public String getDescription() { return Description; }
    public void setDescription(String value) { this.Description = value; }
    
    public String getStartDate() { return StartDate; }
    public void setStartDate(String value) { this.StartDate = value; }
    
    public String getEndDate() { return EndDate; }
    public void setEndDate(String value) { this.EndDate = value; }
    
    public String getUserId() { return UserId; }
    public void setUserId(String value) { this.UserId = value; }
    
    public int getAvailability() { return Availability; }
    public void setAvailability(int value) { this.Availability = value; }
    
    public int getConfirmedBuddies() { return ConfirmedBuddies; }
    public void setConfirmedBuddies(int value) { this.ConfirmedBuddies = value; }
    
    public ArrayList<WeatherConditions> getWeatherCoditions() { return WeatherCoditions; }
    public void setWeatherCoditions(ArrayList<WeatherConditions> value) { this.WeatherCoditions = value; }
    
}
