package Entity;

/**
 * The user entity.
 * @author Shivangi Prajapati
 */
public class User {
    
    private String Id;
    private String Username;
    private String Password;
    private String FullName;
    
    public String getId() { return Id; }
    public void setId(String value) { this.Id = value; }
    
    public String getUsername() { return Username; }
    public void setUsername(String value) { this.Username = value; }
    
    public String getPassword() { return Password; }
    public void setPassword(String value) { this.Password = value; }
    
    public String getFullName() { return FullName; }
    public void setFullName(String value) { this.FullName = value; }   
    
}
