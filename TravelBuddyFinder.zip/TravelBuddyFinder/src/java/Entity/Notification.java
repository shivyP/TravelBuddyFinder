package Entity;

/**
 * The notification entity.
 * @author Shivangi Prajapati
 */
public class Notification {
    private String Id;
    private String SenderId;
    private String RecipientId;
    private String TripId;
    private Boolean Accepted = false;
    private Boolean Request = false;
    private Boolean Response = false;
    private String Message= "A trip request has been received.";
    private String StartDate;
    private String EndDate;
    private int Availability;
    private String Location;
    
    public void setId(String value){this.Id = value;};
    public String getId(){return this.Id;};
    
    public void setSenderId(String value){this.SenderId = value;};
    public String getSenderId(){return this.SenderId;}; 
    
    public void setRecipientId(String value){this.RecipientId = value;};
    public String getRecipientId(){return this.RecipientId;}; 
    
    public void setTripId(String value){this.TripId = value;};
    public String getTripId(){return this.TripId;};
    
    public void setAccepted(Boolean value){this.Accepted = value;};
    public Boolean getAccepted(){return this.Accepted;};
    
    public void setRequest(Boolean value){this.Request = value;};
    public Boolean getRequest(){return this.Request;};
    
    public void setResponse(Boolean value){this.Response = value;};
    public Boolean getResponse(){return this.Response;};
    
    public void setMessage(String value){this.Message = value;};
    public String getMessage(){return this.Message;}; 
    
    public String getStartDate() { return StartDate; }
    public void setStartDate(String value) { this.StartDate = value; }
    
    public String getEndDate() { return EndDate; }
    public void setEndDate(String value) { this.EndDate = value; }
    
    public int getAvailability() { return Availability; }
    public void setAvailability(int value) { this.Availability = value; }
    
    public String getLocation() { return Location; }
    public void setLocation(String value) { this.Location = value; }
}
