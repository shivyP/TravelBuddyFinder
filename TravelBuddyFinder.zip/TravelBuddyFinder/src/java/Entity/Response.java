package Entity;

import java.util.ArrayList;

/**
 * The response entity.
 * @author Shivangi Prajapati
 */
public class Response {
    private String Key;
    private String Message;
    private ArrayList<Tour> ResponseTrips;
    private ArrayList<WeatherConditions> ResponseWeather;
    private ArrayList<Notification> ResponseNotification;
    
    public void setKey(String value){this.Key = value;};
    public String getKey(){return this.Key;};
    
    public void setMessage(String value){this.Message = value;};
    public String getMessage(){return this.Message;};
    
    public void setResponseTrips(ArrayList<Tour> value){this.ResponseTrips = value;};
    public ArrayList<Tour> getResponseTrips(){return this.ResponseTrips;};
    
    public void setResponseWeather(ArrayList<WeatherConditions> value){this.ResponseWeather = value;};
    public ArrayList<WeatherConditions> getResponseWeather(){return this.ResponseWeather;};
    
    public void setResponseNotification(ArrayList<Notification> value){this.ResponseNotification = value;};
    public ArrayList<Notification> getResponseNotification(){return this.ResponseNotification;};
}
