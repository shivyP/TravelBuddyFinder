package Entity;

/**
 * The weather conditions entity.
 * @author Shivangi Prajapati
 */
public class WeatherConditions {
    
    private String datetime;
    private Double tempmax;
    private Double tempmin;
    private String description;
    private String icon;

    public String getDatetime() { return datetime; }
    public void setDatetime(String value) { this.datetime = value; }

    public Double getTempmax() { return tempmax; }
    public void setTempmax(Double value) { this.tempmax = value; }

    public Double getTempmin() { return tempmin; }
    public void setTempmin(Double value) { this.tempmin = value; }

    public String getDescription() { return description; }
    public void setDescription(String value) { this.description = value; }
    
    public String getIcon() { return icon; }
    public void setIcon(String value) { this.icon = value; }
    
}
