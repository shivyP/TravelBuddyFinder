package Factories;

import Entity.WeatherConditions;
import Entity.Notification;
import Entity.Response;
import Entity.Tour;
import java.util.ArrayList;

/**
 * The response factory.
 * @author Shivangi Prajapati
 */
public class ResponseFactory {
    
    public static Response errorResponse(String error)
    {
        String [] errorSplit = error.split(":");
        Response response = new Response();
        response.setKey("Error");
        response.setMessage(errorSplit[1]);
        
        return response;
    }
    
    public static Response successResponse(String key, String msg)
    {         
        Response response = new Response();
        response.setKey(key);
        response.setMessage(msg);
        
        return response;
    }
    
    public static Response successResponse(String key, String msg, ArrayList<Tour> responseTrips)
    {         
        Response response = new Response();
        response.setKey(key);
        response.setMessage(msg);
        response.setResponseTrips(responseTrips);
        
        return response;
    }
    
    public static Response successResponseWeather(String key, String msg, ArrayList<WeatherConditions> responseWeather)
    {         
        Response response = new Response();
        response.setKey(key);
        response.setMessage(msg);
        response.setResponseWeather(responseWeather);
        
        return response;
    }
    
    public static Response successResponseNotification(String key, String msg, ArrayList<Notification> responseNotifications)
    {         
        Response response = new Response();
        response.setKey(key);
        response.setMessage(msg);
        response.setResponseNotification(responseNotifications);
        
        return response;
    }
}
