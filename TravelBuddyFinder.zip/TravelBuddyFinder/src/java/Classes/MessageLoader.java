package Classes;

import java.util.ResourceBundle;

/**
 * The message loader.
 * @author Shivangi Prajapati
 */
public class MessageLoader {
    
    private static final String BUNDLE_NAME = "Resources.ResponseMessages";
    private static ResourceBundle RESOURCE_BUNDLE;
    
    /**
     * The method to get the messages with the given code.
     * @param code to retrieve message.
     * @return the message.
     */
    public static String getMessage(String code)
    {
        String message= "No message found";
     
        RESOURCE_BUNDLE = ResourceBundle.getBundle(BUNDLE_NAME);
        message = RESOURCE_BUNDLE.getString(code);
        return message;
    }    
}
