package Classes;

import Entity.Response;
import Entity.User;
import Exceptions.ImageDataException;
import Exceptions.RegistrationException;
import Exceptions.UserAccessException;
import Factories.ResponseFactory;
import Helpers.SessionData;
import Repository.UserRepository;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

/**
 * The user actions.
 * @author Shivangi Prajapati
 */
@Path("travelBuddy")
public class UserActions {

    private UserRepository userRespository;
    private User currentUser = new User();
       
    
    public UserActions() {
        this.userRespository = new UserRepository();
    }
        
    /**
     * The method to store the session data for the logged user.
     * @param user current user details.
     */
    private void SessionData(User user)
    {
        if(SessionData.CONSTANT_MAP.get(user.getId())== null)
        {
            SessionData.CONSTANT_MAP.put(user.getId(), user);
        }
        this.currentUser = SessionData.CONSTANT_MAP.get(user.getId());
        SessionData.CurrentUserKey = this.currentUser.getId();
    }

    
    /**
     * The getUser method to retrieve logged user's details.
     * @param loggedUser user details.
     * @return response to the client.
     */

    @POST
    @Path("/login")    
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    //cretare the method
    public Response Login(User loggedUser)
    {
        try
        { 
            this.currentUser = this.userRespository.getUser(loggedUser.getUsername(), loggedUser.getPassword());
           
            if(this.currentUser == null){
                return ResponseFactory.errorResponse("Error:" + MessageLoader.getMessage("ER001"));
            }
            this.userRespository.Close();
            
            this.SessionData(this.currentUser);
            
        }catch(UserAccessException ex)
        {
            this.userRespository.Close();
            return ResponseFactory.errorResponse("Error:"+ ex.getLocalizedMessage());
        }
        this.userRespository.Close();
      return ResponseFactory.successResponse("Log in", MessageLoader.getMessage("MS001"));
    }
    
    /**
     * The add users method to record the new user of the system. 
     * @param newUser: details of the user to register.
     * @return UserActions details.
     */
    @POST
    @Path("/register")    
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response Register(User newUser)
    {
        try
        {
            this.currentUser = this.userRespository.addUser(newUser);
            if(this.currentUser == null){
                return ResponseFactory.errorResponse("Error:" + MessageLoader.getMessage("ER003"));
            }
        }catch(RegistrationException ex)
        {
           this.userRespository.Close();
           return ResponseFactory.errorResponse("Error:"+ ex.getLocalizedMessage());
        }
        this.userRespository.Close();
        this.SessionData(this.currentUser);
        return ResponseFactory.successResponse("Registering", MessageLoader.getMessage("MS003"));
    } 
}