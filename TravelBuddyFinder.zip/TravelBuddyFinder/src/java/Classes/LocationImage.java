package Classes;

import Exceptions.ImageDataException;
import Helpers.JsonHelper;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * The location image.
 * @author Shivangi Prajapati
 */
public class LocationImage { 
    private final static String PlaceHolderImage = "https://mtek3d.com/wp-content/uploads/2018/01/image-placeholder-500x500.jpg";
    private final static String URL = "https://api.unsplash.com/photos/random?query=";
    private static final String ACCESS_KEY = "oB4IziKy-cqrud-MJyg96rC5M8YNiOzI2Xj97IC-s9Q"; 
    
    
    /**
     * The method to get the URL for the given location.
     * @param location required for the image search.
     * @return the URL to be added in the database.
     * @throws ImageDataException when errors are encountered.
     */
    public static String getUrl(String location) throws ImageDataException{
        HttpURLConnection conn = null;
        String responseData = PlaceHolderImage;
       
        try
        {
            URL url = new URL("https://api.unsplash.com/photos/random?query=" + location + "&orientation=landscape&count=1");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Client-ID " + ACCESS_KEY);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.connect();
            if (conn.getResponseCode()== 200)
            {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                    String response="";
                    while((response = br.readLine()) !=null)
                    {
                        responseData= response;
                    }
                    responseData = JsonHelper.getImageLink(responseData);
  
                    if(responseData.equals("No link found")){
                        responseData = PlaceHolderImage;
                    }
                        
                }
            } 
        }catch(IOException ex)
        {
           throw new ImageDataException("Image api error:" + ex.getLocalizedMessage());
        }
        return responseData;
    }
}
