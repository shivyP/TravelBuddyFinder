package Classes;

import Exceptions.RandomNumException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import Helpers.JsonHelper;
import Repository.RandomNumRepository;
import java.util.ArrayList;

/**
 * The random number.
 * @author Shivangi Prajapati
 */
public class RandomNum {
  
   // private static RandomNumRepository randomNumRepository;
    /**
     * The method to generate a unique number.
     * @return a unique number.
     */
    private static ArrayList<String> getNum() {
        
        HttpURLConnection conn = null;
        ArrayList<String> randNum= new ArrayList<>();
        String apiResponse = "";
        // call the create json request method
        String requestBody = JsonHelper.createJsonRequest();
        try {
            
            URL url = new URL("https://api.random.org/json-rpc/4/invoke");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);  // shows that the request body has data
            
            OutputStream os = conn.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os, StandardCharsets.UTF_8 );
            osw.write(requestBody); // add body to the request
            osw.flush();
            osw.close(); 
            os.close(); // must be done!!!!
            conn.connect();
            
            // reading the respond socket pratical W2
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String response= null;
            
            while((response = br.readLine()) !=null)
            {
                apiResponse = response;
            }
            
            randNum = JsonHelper.parse(apiResponse);
            // store the data in the dataBase
            
            
            br.close();
          
        } catch (Exception ex) {
            //return randNum = ex.getLocalizedMessage();
        }finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return randNum;
    }
    
    
    /**
     * The method to get a single number from the database.
     * @return a unique number
     */
    public static String getNumber(){
        try{
            RandomNumRepository randomNumRepository = new RandomNumRepository();
            String num = randomNumRepository.getNum();
                
        if( num == null){
            // generate new set of numbers
            //RandomNum.getNum();
            randomNumRepository.saveNumbers(getNum());
            num = getNumber();
        }
       // randomNumRepository.Close();
        return num;
        }catch(RandomNumException ex){
            return null;
        }
    }
}
