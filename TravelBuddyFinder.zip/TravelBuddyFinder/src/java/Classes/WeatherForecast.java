package Classes;

import Entity.WeatherConditions;
import Exceptions.WeatherDataNoFoundException;
import Helpers.JsonHelper;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * The weather forecast.
 * @author Shivangi Prajapati
 */
public class WeatherForecast{
    
    private static final String API_KEY = "key=YXZZABD8MS2HUJ4VPVJ3PKP44";
    private static final String URL ="https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/";
    private static final String TIME = "T13:00:00";

    /**
     * The method to retrieve weather data.
     * @param startDate date for the start of the trip.
     * @param endDate for the last day of the trip.
     * @param location for which data is required.
     * @return weather data.
     */
    public static ArrayList<WeatherConditions> getForcast(String startDate, String endDate, String location) throws WeatherDataNoFoundException
    {
        //ArrayList<CurrentConditions>
        HttpURLConnection conn = null;
        try
        {
            URL url = new URL(URL+"/"+ location+"/"+startDate+TIME+"/"+endDate+TIME+"?"+API_KEY+"&include=current&unitGroup=metric");
            
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();
            String responseData="";
            if (conn.getResponseCode()== 200)
            {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String response= null;
                
                while((response = br.readLine()) !=null)
                {
                    responseData= response;
                }
                br.close();
                // make some checks on the reposne first.
                if(responseData.contains("Bad API Request")){
                    throw new WeatherDataNoFoundException(responseData);
                }else{
                    return JsonHelper.parseWeather(responseData);
                }
               
            }
            else 
            {
                responseData = "No data has been received.";
            }
          
             
        }catch(IOException | WeatherDataNoFoundException ex)
        {
           throw new WeatherDataNoFoundException(ex.getLocalizedMessage());
        }finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return null;
    }
    
}
