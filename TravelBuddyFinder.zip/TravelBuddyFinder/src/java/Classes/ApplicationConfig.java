package Classes;

import java.util.Set;
import javax.ws.rs.core.Application;

/**
 * The application configuration.
 * @author Shivangi Prajapati
 */
@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(Classes.Notifications.class);
        resources.add(Classes.Trip.class);
        resources.add(Classes.UserActions.class);
    }
    
}
