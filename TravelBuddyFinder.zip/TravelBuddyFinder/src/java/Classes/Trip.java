package Classes;

import Entity.WeatherConditions;
import Entity.Response;
import Entity.Tour;
import Exceptions.ImageDataException;
import Exceptions.TripException;
import Exceptions.WeatherDataNoFoundException;
import Factories.ResponseFactory;
import Helpers.JsonHelper;
import Helpers.SessionData;
import Repository.TripRepository;
import com.google.gson.Gson;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 * The trip class
 * @author Shivangi Prajapati
 */
@Path("trip")
public class Trip {
    
    private TripRepository tripRepository; 
    private String currentUserId = SessionData.CurrentUserKey;

    
    public Trip()
    {
        this.tripRepository = new TripRepository(); 
        
    }
   
    /**
     * The method to add a proposed tour to the database.
     * @param newTour details provided by the client in a json format.
     * @return Response to the client.
     */
    @POST
    @Path("/newTrip")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addTour(Tour newTour)
    {   
        try{
            // get the new Id;
            newTour.setId(RandomNum.getNumber());

            // get weather data
            ArrayList<WeatherConditions> weatherInfo = WeatherForecast.getForcast(newTour.getStartDate(), newTour.getEndDate(), newTour.getLocation());

            // check if weather info has been retrived
           if(weatherInfo.isEmpty())
            {
                throw new WeatherDataNoFoundException("Weather forecast not available for: "+ newTour.getLocation());
            }
            newTour.setWeatherCoditions(weatherInfo);
            newTour.setImgUrl(LocationImage.getUrl(newTour.getLocation()));

            // save to the database;      
            newTour.setUserId(this.currentUserId);
            this.tripRepository.addTrip(newTour); 
            this.tripRepository.Close();
        }catch(WeatherDataNoFoundException | TripException | ImageDataException ex)//| TripException ex)
        {
            return ResponseFactory.errorResponse("Error:" + ex.getLocalizedMessage());
        }
        
        return ResponseFactory.successResponse("Trip", MessageLoader.getMessage("MS002"));
    }

    /**
     * The method to retrieve trips added by the logged user.
     * @return response to the client.
     */
    @GET
    @Path("/getUserTrips")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserTrips()
    {
       ArrayList<Tour> allTrips = new ArrayList<>();
       try{
            allTrips=this.tripRepository.getUserTrips(this.currentUserId);
            if(allTrips.isEmpty()){
                return ResponseFactory.errorResponse("Trip error: "+ MessageLoader.getMessage("ER004"));
            }
        }catch(TripException ex)
        {
            this.tripRepository.Close();
            return ResponseFactory.errorResponse("Trip error: "+ ex.getLocalizedMessage());
        } 
       this.tripRepository.Close();
       return ResponseFactory.successResponse("Trip found:",MessageLoader.getMessage("MS004"), allTrips);
    }
    
    /**
     * The method to get trips based on the provided location.
     * @param location for the accurate search.
     * @return response to the client.
     */
    @GET
    @Path("/location")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTourbyLocation(@QueryParam("jsonString") String location)
    {
        //ArrayList<Tour>
       Tour requestTour;
       ArrayList<Tour> allTrips = new ArrayList<>();
       try{
           
           requestTour = new Gson().fromJson(JsonHelper.getJsonObject(location), Tour.class);
           
           allTrips=this.tripRepository.getTourbyLocation(this.currentUserId, requestTour.getLocation());
           if(allTrips.isEmpty())
           {
               return ResponseFactory.errorResponse("Trip error:"+ MessageLoader.getMessage("ER004"));
           }
        }catch(UnsupportedEncodingException | TripException ex)
        {
            return ResponseFactory.errorResponse("Trip error:"+ex.getLocalizedMessage());
        } 
        this.tripRepository.Close();
        return ResponseFactory.successResponse("Trip found:",MessageLoader.getMessage("MS004"), allTrips);
    }
    
    /**
     * The method to delete a trip.
     * @param tripId to delete the correct trip.
     * @return response to the client.
     */
    @DELETE
    @Path("/deleteTrip")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteTrip(@QueryParam("jsonString") String tripId)
    {
       try{
           Tour deleteTour = new Gson().fromJson(JsonHelper.getJsonObject(tripId), Tour.class);
           if(!this.tripRepository.deleteTrip(deleteTour.getId()))
           {
               return ResponseFactory.errorResponse("Weather forcast error:"+MessageLoader.getMessage("ER009"));
           }
        }catch(UnsupportedEncodingException | TripException ex)
        {
            return ResponseFactory.errorResponse("Trip error:" + ex.getLocalizedMessage());
        } 
        this.tripRepository.Close();
        return ResponseFactory.successResponse("Delete:", MessageLoader.getMessage("MS010"));
    }

    /**
     * The method to get the weather forecast information.
     * @param location for which data needs to retrieved.
     * @return response to the client.
     */
    @GET
    @Path("/weather")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getWeatherData(@QueryParam("jsonString") String location)
    {
        //ArrayList<Tour>
       Tour requestTour;
       ArrayList<WeatherConditions> weatherInfo = null;
       try{
            requestTour = new Gson().fromJson(JsonHelper.getJsonObject(location), Tour.class);
            weatherInfo = WeatherForecast.getForcast(requestTour.getStartDate(), requestTour.getEndDate(), requestTour.getLocation());
           
           if(weatherInfo == null || weatherInfo.isEmpty())
           {
               return ResponseFactory.errorResponse("Weather forcast error:"+MessageLoader.getMessage("ER007"));
           }
        }catch(UnsupportedEncodingException | WeatherDataNoFoundException ex)
        {
            return ResponseFactory.errorResponse("Error:" + ex.getLocalizedMessage());
        }
        return ResponseFactory.successResponseWeather("Weather data found:",MessageLoader.getMessage("MS005"), weatherInfo);
    }
}
