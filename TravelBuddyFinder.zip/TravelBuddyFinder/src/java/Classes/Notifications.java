package Classes;

import Entity.Notification;
import Entity.Response;
import Exceptions.NotificationException;
import Factories.ResponseFactory;
import Helpers.SessionData;
import Repository.NotificationRepository;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * The notifications.
 * @author Shivangi Prajapati
 */
@Path("notification")
public class Notifications {
    private NotificationRepository notificationRepository = new NotificationRepository(); 
    private String currentUserId = SessionData.CurrentUserKey;
    
    public Notifications()
    {
    }
    
    /**
     * The method to get all the notifications for the current user.
     * @return response to the client in json format.
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getNotifications(){
        ArrayList<Notification> userNotifications = new ArrayList<>();
        try
        {            
            userNotifications = this.notificationRepository.getUserNotifications(currentUserId);
            this.notificationRepository.Close();
            if(userNotifications.isEmpty())
            {
               return ResponseFactory.successResponse("Notifcation:",MessageLoader.getMessage("MS006"));
            }
        }catch(NotificationException ex)
        {
            return ResponseFactory.errorResponse(ex.getMessage());
        }        
        return ResponseFactory.successResponseNotification("Notification", MessageLoader.getMessage("MS007"),userNotifications);
    }
    
    /**
     * The method to add a new notification.
     * @param notification details to be added for the new notification.
     * @return response to the client in json format.
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addNotification(Notification notification){
        // preapre the nptification object 
        notification.setId(RandomNum.getNumber());
        notification.setSenderId(currentUserId);
        try{
            this.notificationRepository.addNotifications(notification);
            this.notificationRepository.Close();
        }catch(NotificationException ex){
            return ResponseFactory.errorResponse(ex.getMessage());
        }
        return ResponseFactory.successResponse("Notification", MessageLoader.getMessage("MS008"));
    }
    
    /**
     * The method to update the notification status.
     * @param notification to be updated.
     * @return response to the client in json format.
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateStatus(Notification notification){
        // get the id from the string 
        try{
            // check the delete trip and replicate 
            if(this.notificationRepository.updateNotificationStatus(notification.getTripId() ,this.currentUserId)){
                this.notificationRepository.Close();
                return ResponseFactory.successResponse("Upadate", MessageLoader.getMessage("MS009"));
            }
        }catch(NotificationException ex){
            return ResponseFactory.errorResponse("Error:" + ex.getMessage());
        }
        return ResponseFactory.errorResponse("Error:Upadate Failed");
    } 
}
