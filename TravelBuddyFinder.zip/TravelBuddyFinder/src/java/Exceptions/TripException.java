package Exceptions;

/**
 * The trip exception.
 * @author Shivangi Prajapati
 */
public class TripException extends Exception{
    
    public TripException(String errorMessage) {
        super(errorMessage);
    }
}
