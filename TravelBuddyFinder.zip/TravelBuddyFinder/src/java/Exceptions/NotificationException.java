package Exceptions;

/**
 * The notification  exception.
 * @author Shivangi Prajapati
 */
public class NotificationException extends Exception{
    
    public NotificationException(String errorMessage) {
        super(errorMessage);
    }
}
