package Exceptions;

/**
 * The image data exception.
 * @author Shivangi Prajapati
 */
public class ImageDataException extends Exception{
    
    public ImageDataException(String errorMessage) {
        super(errorMessage);
    }
}
