package Exceptions;

/**
 * The user access exception.
 * @author Shivangi Prajapati
 */
public class UserAccessException extends Exception{
    
    public UserAccessException(String errorMessage) {
        super(errorMessage);
    }
}
