/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;

/**
 * The random number exception.
 * @author Shivangi Prajapati
 */
public class RandomNumException extends Exception{
    
    public RandomNumException(String errorMessage) {
        super(errorMessage);
    }
}