package Exceptions;

/**
 * The registration exception.
 * @author Shivangi Prajapati
 */
public class RegistrationException extends Exception{
    
    public RegistrationException(String errorMessage) {
        super(errorMessage);
    }
}
