package Exceptions;

/**
 * The weather data not found exception.
 * @author Shivangi Prajapati
 */
public class WeatherDataNoFoundException extends Exception{
    
    public WeatherDataNoFoundException(String errorMessage) {
        super(errorMessage);
    }
}
