let notMainContent = document.getElementById("notMainContent");
let selectedNotification ;
let sectionToRemove;
class Notification{
    constructor(tripId){
        this.tripId = tripId;
    }
}

function getNotifications(){
    
    $.ajax({
        type: 'GET',
        url: 'http://20.38.42.43:8080/TravelBuddyFinder/webresources/notification',
        success: function(response) {
            displayResponse(response, true);
            
        },
        error: function(error) {
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error occured when connecting with the service"
            });
        }
    });
}

function displayResponse(response, isDisplayNotification)
{
    let key = response["key"];
    let message = response["message"];
    
    if( key === "Error")
    {   
        Swal.fire({
            title: "Failed",
            text: "Request updated failed, try again later.",
            icon: "error"
        }).then(()=>{sectionToRemove.remove();});
    }else if(isDisplayNotification)
    {        
        setNotificationelements(response["responseNotification"])
    }else {
        Swal.fire({
            title: "Sent",
            text: "Request updated",
            icon: "success"
        }).then(()=>{sectionToRemove.remove();});
        
        // update the isdisplayed column 
        updateStatus();
        
    }
}
function setNotificationelements(allNotifications){
    
    if(typeof allNotifications === "undefined"){
        let msg = document.createElement("p");
        msg.classList.add("noResult");
        msg.innerHTML = "No new notifications";
        document.getElementById("notMainContent").appendChild(msg);
    }
    else{
        for ( let n = 0; n < allNotifications.length; n++){
            // display the notifications on the HTMl page
            let section = document.createElement("section");
            section.classList.add("notification");

            let nLocation = document.createElement("p");
            nLocation.classList.add("nlocation");
            nLocation.innerHTML = "Trip Location: "+allNotifications[n]["location"];

            let nStartDate = document.createElement("p");
            nStartDate.classList.add("nStartDate");
            nStartDate.innerHTML = "Strat Date: "+ allNotifications[n]["startDate"];

            let nEndDate = document.createElement("p");
            nEndDate.classList.add("nEndDate");
            nEndDate.innerHTML = "End Date: "+allNotifications[n]["endDate"];

            let nMessage = document.createElement("p");
            nMessage.classList.add("nMessage");
            nMessage.innerHTML = "Message: "+ allNotifications[n]["message"];

            // only when the request is set to true
            console.log("type of : ", typeof allNotifications[n]["request"]);
            if(allNotifications[n]["request"]){
                let article = document.createElement("article");
                article.classList.add("btn");

                // might assign the trip id as value to the button to 
                // store the trip for which an action has been taken

                let accept = document.createElement("button");
                accept.classList.add("accept");
                accept.innerHTML="Accept";
                accept.addEventListener("click", ()=>{
                    selectedNotification = allNotifications[n];
                    selectedNotification["accepted"] = true;
                    sectionToRemove = section;
                    //selectedNotification["message"] = getMessage();
                    getMessage();
                   // section.remove();
                }); 

                let decline = document.createElement("button");
                decline.classList.add("decline");
                decline.innerHTML="Decline";
                decline.addEventListener("click", ()=>{
                    selectedNotification = allNotifications[n];
                    sectionToRemove = section;
                   // selectedNotification["message"]= getMessage();
                   // decline.remove();
                   // accept.remove();
                    getMessage();
                   // sendNotification();
                    //section.remove();
                });

                article.appendChild(accept);
                article.appendChild(decline);
                section.appendChild(article);
            }else {
                let article = document.createElement("article");
                article.classList.add("btn");
                let closeBtn = document.createElement("button");
                closeBtn.classList.add("decline");
                closeBtn.innerHTML="Close";
                closeBtn.addEventListener("click", ()=>{
                    selectedNotification = allNotifications[n];
                    updateStatus();
                    section.remove();
                });
                article.appendChild(closeBtn);
                section.appendChild(article);
            }

            section.appendChild(nLocation);
            section.appendChild(nStartDate);
            section.appendChild(nEndDate);
            section.appendChild(nMessage);
            document.getElementById("notMainContent").appendChild(section); 
        }
    }
}

function sendNotification(){
    // send the response notification
    selectedNotification["response"]= true;
    selectedNotification["request"]= false;
    selectedNotification["recipientId"] = selectedNotification["senderId"]
    
    
    
    
    
    console.log("Sending "+ JSON.stringify(selectedNotification));
    $.ajax({
        type: 'POST',
        url: 'http://20.38.42.43:8080/TravelBuddyFinder/webresources/notification', 
        contentType: 'application/json',
        data: JSON.stringify(selectedNotification),
        success: function(response) {
            // Handle the successful response here
            if(response != null){
                displayResponse(response, false);
            }
            //window.location.replace("home.html");
        },
        error: function(error) {
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error occured when connecting with the service"
            });
        }
    });
}

function updateStatus(){
    let trip = new Notification(selectedNotification["tripId"]);  
    
    $.ajax({
        type: 'PUT',
        url: 'http://20.38.42.43:8080/TravelBuddyFinder/webresources/notification', 
        contentType: 'application/json',
        data: JSON.stringify(trip),
        success: function(response) {
            if(response!=null){
                //displayResponse(response, false);
            }
        },
        error: function(error) {
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error occured when connecting with the service"
            });
        }
    });
}

function getMessage(){
    Swal.fire({
      title: 'Enter message',
      input: 'textarea',
      inputPlaceholder: 'Type something...',
      showCancelButton: true,
      cancelButtonText: 'Cancel',
      confirmButtonText: 'Submit',
    }).then((result) => {
      if (result.isConfirmed) {
        selectedNotification["message"] = result.value;
        console.log('Entered Text:', selectedNotification["message"]);
       // Swal.fire('Submitted!');
        sendNotification();
      }
    });
}


getNotifications();

