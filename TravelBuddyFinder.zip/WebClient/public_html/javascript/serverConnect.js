let successResponse = false;

function createRequest(){
    var currentUser = new Object();
    currentUser.username = document.getElementById("uname").value;
    currentUser.password = document.getElementById("psw").value;

    $.ajax({
        type: 'POST',
        url: 'http://20.38.42.43:8080/TravelBuddyFinder/webresources/travelBuddy/login', 
        contentType: 'application/json',
        data: JSON.stringify(currentUser),
        success: function(response) {
              if(response!=null){
                displayResponse(response);
            }
        },
        error: function(response) {
            // Handle errors here
            console.log(response);
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error occured when connecting with the service"
            });
        }
    });
}

function displayResponse(response)
{
    console.log("Error:", response["message"]);
    let msg=document.getElementById("msg");
    msg.classList.remove("msg-rejected");
    let key = response["key"];
    let message = response["message"];
    msg.classList.add("msg-accepted");
    msg.innerHTML=message;
    if( key === "Error")
    {   msg.classList.remove("msg-accepted");         
        msg.classList.add("msg-rejected");
    }else
    {
        msg.classList.add("msg-accepted");
        // go to home page
        setTimeout(() => { console.log('10 second passed'); }, 30000);
        window.location.replace("home.html");
    }
}



