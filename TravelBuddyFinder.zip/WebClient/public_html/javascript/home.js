let loc = document.getElementById("loc");
let currentLoc = document.getElementById("location");
loc.addEventListener("click", getTrips);
// send the request to get all the trips for with the iven location

class Tour{
    constructor(location)
    {
        this.Location = location;

    }
}

function getTrips(){
    let trips = new Tour(currentLoc.value);
    console.log("Location:" , typeof(currentLoc.value));
    if(currentLoc.value.length > 0){
        const jsonQueryString = encodeURIComponent(JSON.stringify(trips));
        const url = 'http://20.38.42.43:8080/TravelBuddyFinder/webresources/trip/location';

        // Append the JSON data to the URL
        const finalUrl = `${url}?jsonString=${jsonQueryString}`;
        console.log("final url:" + finalUrl);
        $.ajax({
            type: 'GET',
            url: finalUrl,
            success: function(response) {
                // Handle the successful response here
                console.log('Success:', response);
                getResponse(response);

               // console.log(localStorage.getItem('tripByLocation'))
            },
            error: function(error) {
                console.log(error);
                Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error occured when connecting with the service"
            });
            }
        });
    }
    else{
        Swal.fire({
            title: "Invalid Location",
            icon: "warning"
        });
    }
}

function getResponse(response){
    localStorage.setItem("location",currentLoc.value );
    localStorage.setItem('tripByLocation', JSON.stringify(response["responseTrips"]));
    window.location.replace("DisplayTrips.html");
}

