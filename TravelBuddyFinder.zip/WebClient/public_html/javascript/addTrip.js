let inpField = document.getElementsByClassName("inpField");
let destination=document.getElementById("location");
let availability=document.getElementById("availability");
let startDate=document.getElementById("startDate");
let endDate=document.getElementById("endDate");
let tripdesc= document.getElementById("tripDesc");
let sButton=document.getElementById("signInButton");
let sucMsg=document.getElementById("msg");
let msg=document.getElementById("msg");
let weatherData="";


class Tour{
    constructor(location,startDate,endDate,availability,description)
    {
        this.location = location;
        this.startDate = startDate;
        this.endDate = endDate;
        this.availability = availability;
        this.description = description;
    }
}

destination.addEventListener('focus',() => { startFloat(0)});
availability.addEventListener('focus',() => { startFloat(1)});
tripdesc.addEventListener('focus',() => { startFloat(2)});
startDate.addEventListener('focus',() => { startFloat(3)});
endDate.addEventListener('focus',() => { startFloat(4)});

destination.addEventListener('blur', () => {endFloat(0,destination.value)});
availability.addEventListener('blur', () => {endFloat(1,availability.value)});
tripdesc.addEventListener('blur', () => {endFloat(2,tripdesc.value)});
startDate.addEventListener('blur', () => {endFloat(3,startDate.value)});
endDate.addEventListener('blur', () => {endFloat(4,endDate.value)});

destination.addEventListener('input',() => { 
    destination.setCustomValidity('');
});
availability.addEventListener('input',() => { 
    availability.setCustomValidity('');
});

startDate.addEventListener('input',() => { 
    startDate.setCustomValidity('');
});
endDate.addEventListener('input',() => { 
    endDate.setCustomValidity('');
});
tripdesc.addEventListener('input',() => { 
    endDate.setCustomValidity('');
});

endDate.addEventListener("change", getInfo);

//the floating input fields
function startFloat(index){
    inpField[index].classList.add('active');

};
function endFloat(index, element){
    if (element=='') {
        inpField[index].classList.remove('active');
      
    }
       
}

function getInfo(){
     // e.preventDefault();
    let currentDate = new Date(); 
    console.log("Date:"+ currentDate);
    
    let sDate= new Date(startDate.value);
    let eDate= new Date(endDate.value);
    
    addEvents();
    console.log("desc"+tripdesc.value.length);
    
    if(sDate < currentDate || sDate > eDate){
        msg.innerHTML="In valid dates provided";
        msg.classList.add("msg-rejected");
    }else if(availability.value.length === 0)
    {   msg.innerHTML="In valid availability provided";
        msg.classList.add("msg-rejected");
    }else if (tripdesc.value.length === 0 || tripdesc.value.length < 30){
        msg.innerHTML="Please provide a trip description!";
        msg.classList.add("msg-rejected");
    }else if(isCity(destination.value)){
        destination.setCustomValidity('Enter valid location');
        msg.innerHTML="In valid location";
        msg.classList.add("msg-rejected");
    }
}

function addEvents(){    
    // check the value of each filed and if that is different than null
    // add the event listener
    if(destination.value!= null && startDate.value !=null && endDate.value !=null){
        // add event listener 
        destination.addEventListener("change", getInfo);
        startDate.addEventListener("change", getInfo);
        availability.addEventListener("change", getInfo);
        tripdesc.addEventListener("change", getInfo);
        endDate.addEventListener("change", getInfo);        
        document.getElementById("signInButton").style.visibility="hidden";
        document.getElementById("formContent").scrollIntoView();
        
    }

}

function isCity(content){  
    let size=content.length;
    if (size<=1){
        return true;
    }
    for (var i=0; i<size;i++){
        if(!(content[i]>='a' && content[i]<='z' || content[i]==' '))  // no need of brackets as the && has higher priority
            if (!(content[i]>='A' && content[i]<='Z'|| content[i]==' ')){
                return true;
            }
    }
    // call the get method to get the weather data;
    
    getWeatherData();

}//end of function


function getWeatherData(){
    let trip = new Tour(destination.value, startDate.value, endDate.value, availability.value);
    let correctTrip={};
    for (var key in JSON.parse(JSON.stringify(trip))) {
        if (trip.hasOwnProperty(key)) {
            var capitalizedKey = key.charAt(0).toUpperCase() + key.slice(1);
            correctTrip[capitalizedKey] = trip[key];
        }
    }
    const jsonQueryString = encodeURIComponent(JSON.stringify(correctTrip));
    const url = 'http://20.38.42.43:8080/TravelBuddyFinder/webresources/trip/weather';

    const finalUrl = `${url}?jsonString=${jsonQueryString}`;
    $.ajax({
        type: 'GET',
        url: finalUrl,
        success: function(response) {
            displayResponse(response, false);
        },
        error: function(error) {
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error occured when connecting with the service"
            });
        }
    });
}

function saveTrip(){
    let newTrip = new Tour(destination.value, startDate.value, endDate.value, availability.value, tripdesc.value);
    
    console.log("test:"+JSON.stringify(newTrip).toLocaleString());
    // make the post request
     $.ajax({
        type: 'POST',
        url: 'http://20.38.42.43:8080/TravelBuddyFinder/webresources/trip/newTrip', 
        contentType: 'application/json',
        data: JSON.stringify(newTrip),
        success: function(response) {
            // Handle the successful response here
            if(response!=null){
                console.log("Response:"+ JSON.stringify(response));
                displayResponse(response, true);
             }
        },
        error: function(error) {
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error occured while saving the trip."
            });
        }
    });
}

function displayResponse(response, isPost)
{
    msg.classList.remove("msg-rejected");
    let key = response["key"];
    let message = response["message"];
    msg.classList.add("msg-accepted");
    msg.innerHTML=message;
    if( key === "Error")
    {   msg.classList.remove("msg-accepted");         
        msg.classList.add("msg-rejected");
    }else if(!isPost)
    {
        msg.classList.add("msg-accepted");
        weatherData = response["responseWeather"];
        getElements();
    }else {
        msg.classList.add("msg-accepted");
        //removeListeners();
        Swal.fire({
            icon: "success",
            title: "Sent",
            text: "Trip added!"
        }).then(() => {
            location.reload();
        });
        
    }
   
}


function getElements(){
    if(document.querySelectorAll(".weatherInfo")){
        for (const child of document.getElementById("wData").children) {
            child.remove();
        }
    }
    
    let weather = document.createElement("div");
    weather.classList.add("weather");

    for (let i=0; i< weatherData.length; i++){
       let count = i+1;
       let day = document.createElement("div");
       day.classList.add("weatherInfo")
       
       let dayCount = document.createElement("p");
       dayCount.innerHTML="<b>Day "+ count +"</b>";
       
       let date = document.createElement("p");
       date.innerHTML="<b>"+weatherData[i]["datetime"]+"</b>";
       
       let dayImg = document.createElement("img");
       dayImg.src ="assets/weatherIcons/"+weatherData[i]["icon"]+".png";
       console.log(dayImg.src);
       
       let temp = document.createElement("p");
       temp.textContent="H:"+weatherData[i]["tempmin"]+"   L:"+weatherData[i]["tempmax"];
                   
       let desc1 = document.createElement("p");
       desc1.textContent=weatherData[i]["description"];
       
       day.appendChild(dayCount);
       day.appendChild(date);
       day.appendChild(dayImg);
       day.appendChild(temp);
       day.appendChild(desc1);
       weather.appendChild(day);
    }
    document.getElementById("wData").appendChild(weather).scrollIntoView();
    document.getElementById("signInButton").style.visibility="visible";
}

