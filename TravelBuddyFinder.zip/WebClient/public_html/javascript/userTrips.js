// make the get call once the page is loaded
let msg = document.getElementById("msg");

class Tour{
    constructor(id)
    {
        this.Id = id;
    }
}
function getUserTrips(){
    const url = 'http://20.38.42.43:8080/TravelBuddyFinder/webresources/trip/getUserTrips';

    $.ajax({
        type: 'GET',
        url: url,
        success: function(response) {
            // Handle the successful response here
            console.log('Success:', response);
            displayResponse(response);

           // console.log(localStorage.getItem('tripByLocation'))
        },
        error: function(error) {
            // Handle errors here
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error occured when connecting with the service"
            });
        }
    });
}

function displayResponse(response, isRemoveTrip)
{
    msg.classList.remove("msg-rejected");
    let key = response["key"];
    let message = response["message"];
    msg.classList.add("msg-accepted");
    msg.innerHTML=message;
    if( key === "Error" && !isRemoveTrip)
    {   msg.classList.add("msg-rejected");
        msg.innerHTML="No trips found!";
    }else if( !isRemoveTrip)
    {
        msg.innerHTML="";
        msg.classList.add("msg-accepted");
        getTrips(response["responseTrips"]);
        console.log("Response trips:", response["responseTrips"]);
    }
    
    if( key === "Error" && isRemoveTrip)
    {  
        Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error has occured while removing the trip."
            });
    }else if(isRemoveTrip)
    {
        Swal.fire({
                icon: "success",
                title: "Removed",
                text: "The trip has been removed successfully"
            });
    }
}

function getTrips(trips){
    if(trips !== "undefined"){
        for (let i = 0; i < trips.length; i++) {
            //console.log(i);
              dispTrips(trips[i]);
        }}
}
function dispTrips(trip){
    // create a section 
    console.log(trip);
    let singleTrip = document.createElement("section");
    singleTrip.classList.add("dispTrips");

    //-----------------------------------------------------
    let img = document.createElement("img");
    img.src=trip["imgUrl"];
    singleTrip.appendChild(img);

    //-----------------------------------------------------
    let article = document.createElement("article");
    article.classList.add("desc");

    //-----------------------------------------------------
    let title = document.createElement("h3");
    title.classList.add("user_location");
    title.textContent=trip["location"];
    title.style.fontFamily= "Jost, sans-serif";
    title.style.fontSize="18px";

    article.appendChild(title);

    //-----------------------------------------------------
    let desc= document.createElement("p");
    desc.classList.add("user_description");
    desc.textContent=trip["description"];

    article.appendChild(desc);

    //-----------------------------------------------------
    let startDate = document.createElement("p");
    startDate.classList.add("user_startDate");
    startDate.innerHTML="<b>Start Date:</b> "+ trip["startDate"];

    article.appendChild(startDate);

    //-----------------------------------------------------
    let endDate = document.createElement("p");
    endDate.classList.add("user_endDate");
    endDate.innerHTML="<b>End Date:</b> "+ trip["endDate"];

    article.appendChild(endDate);
    
    //-----------------------------------------------------
    let avaliability = document.createElement("p");
    avaliability.classList.add("user_avaliability");
    avaliability.innerHTML="<b>Avaliability:</b> "+ trip["availability"];


    article.appendChild(avaliability);
    
    //-----------------------------------------------------
    let confirmedBuddies = document.createElement("p");
    confirmedBuddies.classList.add("user_confirmedBuddies");
    confirmedBuddies.innerHTML="<b>Confirmed Buddies:</b> "+ trip["confirmedBuddies"];

    article.appendChild(confirmedBuddies);
    
    //-----------------------------------------------------
    let deleteTrip = document.createElement("button");
    deleteTrip.classList.add("deleteTrip");
    deleteTrip.value=trip["id"];
    deleteTrip.addEventListener("click", ()=>{ removeTrip(deleteTrip.value); singleTrip.remove()});
    deleteTrip.textContent="Delete Trip";

    article.appendChild(deleteTrip);
    singleTrip.appendChild(article);
    // append it to the main content section

    document.getElementById("mainSection").appendChild(singleTrip);
}

function removeTrip(tripId){
    const jsonQueryString = encodeURIComponent(JSON.stringify(new Tour(tripId)));
    const url = 'http://20.38.42.43:8080/TravelBuddyFinder/webresources/trip/deleteTrip';
    const finalUrl = `${url}?jsonString=${jsonQueryString}`;
    console.log("final url:" + finalUrl);
    //delete request

    $.ajax({
        type: 'DELETE',
        url: finalUrl, 
        contentType: 'application/json',
        success: function(response) {
            // Handle the successful response here
            if(response!=null){
                 
                displayResponse(response, true);
                console.log("Response:"+ JSON.stringify(response));
                
             }
            //window.location.replace("home.html");
        },
        error: function(error) {
            // Handle errors here
             Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error occured when connecting with the service"
            });
        }
    }); 
    
}

getUserTrips();