let zoomImage=document.getElementById("zoomImage");
let zBG = document.querySelector(".zBG");
let closeWindow=document.querySelector(".close"); 
let result = document.getElementById("results");
let trips=localStorage.getItem('tripByLocation');//= JSON.parse(localStorage.getItem('tripByLocation'));

let loc = document.querySelector(".searchLocation");
let selectedTrip;

class Notification{
    constructor(recipientId, request, tripId)
    {
        this.recipientId = recipientId;
        this.request = request; 
        this.tripId = tripId;
    }
}


function dispTrips(trip){
    // create a section 
    console.log(trip);
    let singleTrip = document.createElement("section");
    singleTrip.classList.add("dispTrips");

    //-----------------------------------------------------
    let img = document.createElement("img");
    img.src=trip["imgUrl"];
    singleTrip.appendChild(img);

    //-----------------------------------------------------
    let article = document.createElement("article");
    article.classList.add("desc");

    //-----------------------------------------------------
    let title = document.createElement("h3");
    title.classList.add("location");
    title.textContent=trip["location"];
    title.style.fontFamily= "Jost, sans-serif";
    title.style.fontSize="18px";

    article.appendChild(title);

    //-----------------------------------------------------
    let desc= document.createElement("p");
    desc.classList.add("description");
    desc.textContent=trip["description"];

    article.appendChild(desc);

    //-----------------------------------------------------
    let startDate = document.createElement("p");
    startDate.classList.add("startDate");
    startDate.innerHTML="<b>Start Date:</b> "+ trip["startDate"];

    article.appendChild(startDate);

    //-----------------------------------------------------
    let endDate = document.createElement("p");
    endDate.classList.add("endDate");
    endDate.innerHTML="<b>End Date:</b> "+ trip["endDate"];

    article.appendChild(endDate);

    //-----------------------------------------------------
    let viewDetails = document.createElement("button");
    viewDetails.classList.add("viewDetalis");
    viewDetails.value=trip["id"];
    viewDetails.addEventListener("click", ()=>{
        selectedTrip = trip;
        zoomDisplay();});
    viewDetails.textContent="View Details";

    article.appendChild(viewDetails);
    singleTrip.appendChild(article);
    // append it to the main content section

    document.getElementById("mainSection").appendChild(singleTrip);
}


function getTrips(){
    trips= JSON.parse(localStorage.getItem('tripByLocation'));
    for (let i = 0; i < trips.length; i++) {
        //console.log(i);
          dispTrips(trips[i]);
    }
}


//animation 
var opacity=0;
var interval=0;

let scaleWindow=0.1;

function zoomDisplay(){
   
   zoomImage.style.transform="scale"+"("+scaleWindow+")";
   interval=setInterval(openWindow,130);
   getElements();
}


function openWindow(){
    opacity=Number(getComputedStyle(zoomImage).getPropertyValue("opacity"));
    console.log("op", scaleWindow);
      if (opacity<1){
         console.log("in if");
         
         opacity=opacity+0.2;
         scaleWindow+=0.18;
         zoomImage.style.opacity=opacity;
         zoomImage.style.transform="scale"+"("+scaleWindow+")";
         zoomImage.style.visibility="visible";   
         zBG.style.visibility="visible";
         
     }
     else {
        clearInterval(interval);
    }  
    
};
if(closeWindow){
    closeWindow.addEventListener('click', ()=>{
    zoomImage.style.visibility="hidden";
    zBG.style.visibility="hidden";
    zoomImage.style.opacity=0;
    
    scaleWindow=0.1;  
    document.querySelector(".zoomTrip").remove();
    document.getElementById("content").classList.remove("bgContent");
});
}


/*
// view details 
var opacity=0;
var interval=0;

let scaleWindow=0.1;

function zoomDisplay(){
  // console.log("id"+ selectedTrip["id"]);
   document.body.scrollTop = 0;
   document.documentElement.scrollTop = 0;
   zoomImage.style.transform="scale"+"("+scaleWindow+")";
   interval=setInterval(openWindow,130);
   getElements();
}


function openWindow(){
   
    document.getElementById("content").classList.add("bgContent");
    opacity=Number(getComputedStyle(zoomImage).getPropertyValue("opacity"));
    if (opacity<1){
        
        opacity=opacity+0.2;
        scaleWindow+=0.18;
        zoomImage.style.opacity=opacity;
        zoomImage.style.transform="scale"+"("+scaleWindow+")";
        zoomImage.style.visibility="visible";   
        zBG.style.visibility="visible";  
    }
    else {
        clearInterval(interval);
    }  
}

if(closeWindow){
    closeWindow.addEventListener('click', ()=>{
        zoomImage.style.visibility="hidden";
        zBG.style.visibility="hidden";
        zoomImage.style.opacity=0;
        scaleWindow=0.1;        
        document.querySelector(".zoomTrip").remove();
        document.getElementById("content").classList.remove("bgContent");
    });
}


*/




// add the elements of the zoom window
function getElements(){
    let content = document.createElement("div");
    content.classList.add("zoomTrip");
    
    let locTittle = document.createElement("h2");
    locTittle.innerHTML="Destination:"+"&nbsp;<i>"+selectedTrip["location"]+"</i>";
    locTittle.style.marginTop="10px";
    let desc= document.createElement("p");
    desc.textContent=selectedTrip["description"];
    desc.style.marginTop="10px";
    let dates= document.createElement("p");
    dates.innerHTML="<b>Start Date:</b> "+selectedTrip["startDate"]+"&emsp;&emsp;<b>End Date:</b> "+selectedTrip["endDate"]
    +"&emsp;&emsp;<b>Availability: </b>"+selectedTrip["availability"]+"&emsp;&emsp;<b>Places booked: </b>"+selectedTrip["confirmedBuddies"];
    dates.style.marginTop="20px"; 
    
    
    let weather = document.createElement("div");
    weather.classList.add("weather");
    let weatherConditions = selectedTrip["weatherCoditions"];
    
    console.log("test:"+weatherConditions);
    for (let i=0; i< weatherConditions.length; i++){
       let day = document.createElement("div");
       day.classList.add("weatherInfo")
       
       let date = document.createElement("p");
       date.textContent=weatherConditions[i]["datetime"];
       
       let dayImg = document.createElement("img");
       dayImg.src ="assets/weatherIcons/"+weatherConditions[i]["icon"]+".png";
       console.log(dayImg.src);
       
       let temp = document.createElement("p");
       temp.textContent="H:"+weatherConditions[i]["tempmin"]+"   L:"+weatherConditions[i]["tempmax"];
                   
       let desc1 = document.createElement("p");
       desc1.textContent=weatherConditions[i]["description"];
       
       day.appendChild(date);
       day.appendChild(dayImg);
       day.appendChild(temp);
       day.appendChild(desc1);
       weather.appendChild(day);
    }
    
    let showIn = document.createElement("button");
    showIn.textContent= "Show intrest";
    showIn.classList.add("showIntrest");
    showIn.addEventListener("click", ()=>{
        sendRequest();
    })
    
    content.appendChild(locTittle);
    content.appendChild(desc);
    content.appendChild(dates);
    content.appendChild(weather);
    content.appendChild(showIn);
    zoomImage.appendChild(content);

}


function sendRequest(){
    // create the notification object;
    let notification = new Notification(selectedTrip["userId"],true, selectedTrip["id"]);
    console.log("Notification:"+ JSON.stringify(notification));
    $.ajax({
        type: 'POST',
        url: 'http://20.38.42.43:8080/TravelBuddyFinder/webresources/notification', 
        contentType: 'application/json',
        data: JSON.stringify(notification),
        success: function(response) {
            // Handle the successful response here
            if(response!=null){
                 
                displayResponse(response);
                console.log("Response:"+ JSON.stringify(response));
                
            }
            //window.location.replace("home.html");
        },
        error: function(error) {
                    
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error has occured while conneting with the server."
            });
        }
    });
    
}

function displayResponse(response)
{
    let key = response["key"];
    let message = response["message"];
    if( key === "Error")
    {
        Swal.fire({
            title: "Failed",
            text: message,
            icon: "error"
        });
    }else
    {
        Swal.fire({
            title: "Sent",
            text: message,
            icon: "success"
        });
    }
}


if(trips === "undefined"){
    loc.innerHTML ="Trips for: "+ localStorage.getItem('location') +"&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Total:"+0;
    var noResult = document.createElement('div');
    noResult.innerHTML="No trips found!";
    noResult.style.cssText="font-weight:bold; font-size:18px; margin-left:10%";
    document.body.appendChild(noResult);
}
else{
    trips=JSON.parse(localStorage.getItem('tripByLocation'));
    loc.innerHTML ="Trips for: "+ trips[0]["location"] +"&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Total:"+trips.length;
    getTrips();
}

