class User{
    constructor(username, password, fullname)
    {
        this.username = username;
        this.password = password;
        this.fullName = fullname;
    }
}

let msg=document.getElementById("msg");
let fname=document.getElementById("fName");
let username=document.getElementById("uName");
let password=document.getElementById("password");

function register()
{
    let newUser = new User(username.value,password.value,fname.value);   
    console.log("test:"+newUser.username);
    // make the post request
    $.ajax({
        type: 'POST',
        url: 'http://20.38.42.43:8080/TravelBuddyFinder/webresources/travelBuddy/register', 
        contentType: 'application/json',
        data: JSON.stringify(newUser),
        success: function(response) {
            // Handle the successful response here
            if(response!=null){
                 
                displayResponse(response);
                console.log("Response:"+ JSON.stringify(response));
                
             }
            //window.location.replace("home.html");
        },
        error: function(error) {
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "An error occured when connecting with the service"
            });
        }
    });

}

   
function displayResponse(response)
{
    msg.classList.remove("msg-rejected");
    let key = response["key"];
    let message = response["message"];
    msg.classList.add("msg-accepted");
    msg.innerHTML=message;
    if( key=="Error")
    {   msg.classList.remove("msg-accepted");         
        msg.classList.add("msg-rejected");
    }else
    {
        msg.classList.add("msg-accepted");
        // go to home page
        setTimeout(() => { console.log('1 second passed'); }, 2000);
        window.location.replace("home.html");
    }
}